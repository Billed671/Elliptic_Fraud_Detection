"""Model implementations."""
